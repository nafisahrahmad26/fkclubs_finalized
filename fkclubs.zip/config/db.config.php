<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$serverhost = "10.26.30.17";
$username   = "ca23029";
$password   = "ca23029";
$database   = "ca23029";

$conn = mysqli_connect($serverhost, $username, $password, $database);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>